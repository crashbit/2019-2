//
//  MySupplementaryView.swift
//  Collection-Diplomado
//
//  Created by Germán Santos Jaimes on 3/23/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class MySupplementaryView: UICollectionReusableView {
    @IBOutlet weak var headerLabel: UILabel!
    
}
