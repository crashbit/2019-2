//
//  ViewController.swift
//  Diplomado-Frameworks
//
//  Created by Germán Santos Jaimes on 3/23/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var botoncito: BotonIB!
    let boton: Boton = {
        let b = Boton()
        b.setTitle("click please pleas please", for: .normal)
        //b.translatesAutoresizingMaskIntoConstraints = false
        //b.backgroundColor = .blue
        b.addTarget(self, action: #selector(clickon), for: .touchUpInside)
        return b
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.addSubview(boton)
        boton.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        boton.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
    }
    
    @objc func clickon(){
        print("click")
    }
    
    
    @IBAction func ejecuta(_ sender: BotonIB) {
        botoncito.shake()
    }
    

}

