//
//  SecondViewController.swift
//  TestTablas
//
//  Created by Germán Santos Jaimes on 3/9/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    var dato: String = ""
    @IBOutlet weak var etiqueta: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        etiqueta.text = dato
    }
    
    @IBAction func regresar(_ sender: UIButton) {
        
        dismiss(animated: true, completion: nil)
    }
    
    

}
