//
//  ViewController.swift
//  TestTablas
//
//  Created by Germán Santos Jaimes on 3/9/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var tabla: UITableView!
    
    var alumnos: [String] = ["Luis", "Pedro", "Alejandro", "Martin"]

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return alumnos.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath)
        
        cell.textLabel?.text = alumnos[indexPath.row]
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = tableView.cellForRow(at: indexPath)
        
        let optionMenu = UIAlertController(title: "Reprobar alumno", message: "Desea reprobar a este alumno?", preferredStyle: .alert)
        
        let cancelAction = UIAlertAction(title: "Cancelar", style: .cancel, handler: nil)
        
        let okAction = UIAlertAction(title: "Reprobar", style: .default) { (UIAlertAction) in
            
            if cell?.accessoryType.rawValue == 0{
                cell?.accessoryType = .checkmark
            }else{
                cell?.accessoryType = .none
            }
            
            self.performSegue(withIdentifier: "toSecondView", sender: self)
        }

        
        optionMenu.addAction(cancelAction)
        optionMenu.addAction(okAction)
        present(optionMenu, animated: true, completion: nil)
    }
    
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        return false
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let indexPath = tabla.indexPathForSelectedRow
        
        let secondView = segue.destination as? SecondViewController
        secondView?.dato = alumnos[(indexPath?.row)!]
    }


}

