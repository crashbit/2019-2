//
//  ViewController.swift
//  TestTablas
//
//  Created by Germán Santos Jaimes on 3/9/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var tabla: UITableView!
    
    var alumnos: [String] = ["Luis", "Pedro", "Alejandro", "Martin"]

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return alumnos.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath)
        
        cell.textLabel?.text = alumnos[indexPath.row]
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = tableView.cellForRow(at: indexPath)
        
        let optionMenu = UIAlertController(title: "Reprobar alumno", message: "Desea reprobar a este alumno?", preferredStyle: .alert)
        
        let cancelAction = UIAlertAction(title: "Cancelar", style: .cancel, handler: nil)
        
        let okAction = UIAlertAction(title: "Reprobar", style: .default) { (UIAlertAction) in
            
            if cell?.accessoryType.rawValue == 0{
                cell?.accessoryType = .checkmark
            }else{
                cell?.accessoryType = .none
            }
            
            self.performSegue(withIdentifier: "toSecondView", sender: self)
        }

        
        optionMenu.addAction(cancelAction)
        optionMenu.addAction(okAction)
        present(optionMenu, animated: true, completion: nil)
    }
    
//    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
//        if editingStyle == .delete{
//            alumnos.remove(at: indexPath.row)
//            tableView.reloadData()
//        }
//    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let deleteAction = UIContextualAction(style: .destructive, title: "Borrar") { (action, sourceView, completionHandler) in
            self.alumnos.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade )
            
            completionHandler(true)
        }
        
        let swipeConfiguration = UISwipeActionsConfiguration(actions: [deleteAction])
        
        return swipeConfiguration
    }
    
    func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let shareAction = UIContextualAction(style: .normal, title: "Compartir") { (action, sourceView, completion) in
            let defaultText = "Reprobando a " + self.alumnos[indexPath.row]
            
            let activityController = UIActivityViewController(activityItems: [defaultText], applicationActivities: nil)
            
            self.present(activityController, animated: true, completion: nil)
            completion(true)
        }
        
        shareAction.backgroundColor = .green
        
        let swipeConfiguration = UISwipeActionsConfiguration(actions: [shareAction])
        
        return swipeConfiguration
    }
    
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        return false
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let indexPath = tabla.indexPathForSelectedRow
        
        let secondView = segue.destination as? SecondViewController
        secondView?.dato = alumnos[(indexPath?.row)!]
    }


}

