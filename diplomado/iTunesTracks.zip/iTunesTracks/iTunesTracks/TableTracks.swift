//
//  TableTracks.swift
//  iTunesTracks
//
//  Created by Germán Santos Jaimes on 3/16/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class TableTracks: UITableViewController, UISearchBarDelegate{
    
    var tracks: [Tracks] = []
    
    let searchController = UISearchController(searchResultsController: nil)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.prefersLargeTitles = true
        
        navigationItem.title = "Lista de canciones"
        
        navigationItem.searchController = searchController
        navigationItem.hidesSearchBarWhenScrolling = false
        
        searchController.dimsBackgroundDuringPresentation = false
        searchController.searchBar.delegate = self
        
        getTracks()
        
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tracks.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celdaTrack", for: indexPath)
        
        cell.textLabel!.text = tracks[indexPath.row].trackName
        
        return cell
    }
    
    func getTracks(){
        let url = URL(string: "https://itunes.apple.com/search?term=mecano")
        
        let jsonDecoder = JSONDecoder()
        
        let task = URLSession.shared.dataTask(with: url!) { (data, response, error) in
            
            if let data = data, let results = try? jsonDecoder.decode(Results.self, from: data){
                var temp:  [Tracks] = []
                for track in results.results{
                    print(track.trackName)
                    temp.append(track)
                }
                self.tracks = temp
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            }
        }
        
        task.resume()

        
    }
    
}
