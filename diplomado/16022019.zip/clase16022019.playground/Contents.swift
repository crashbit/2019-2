import UIKit

var cadena: String? = nil

// NIL = NULL

cadena = "Hola mundo"

//Forced unwrapping
//print(cadena!)


//Optional Binding
if let variable = cadena{
    print(variable)
}else{
    print("No hay valor alguno")
}


var cadenaBackup = cadena ?? "Hola"
print(cadenaBackup)



