//
//  SecondViewController.swift
//  Dia16022019-1
//
//  Created by Germán Santos Jaimes on 2/16/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    var valor: String = ""
    
    @IBOutlet weak var etiqueta: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .orange
        print(valor)
        
        etiqueta.text = valor
    }
    
    @IBAction func regresar(_ sender: UIButton) {
        
        navigationController?.popViewController(animated: true)
        
    }
    
}
