//
//  ThirdViewController.swift
//  Dia16022019-1
//
//  Created by Germán Santos Jaimes on 2/16/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {

    var firstViewController: ViewController?

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .magenta
        // Do any additional setup after loading the view.
    }
    
    @IBAction func regresarVista1(_ sender: UIButton) {
        //firstViewController?.dataReceived(data: "hola desde la tercera vista")
        firstViewController?.datos = "Saludos desde la tercera"
        dismiss(animated: true, completion: nil)
    }
    
    
}
