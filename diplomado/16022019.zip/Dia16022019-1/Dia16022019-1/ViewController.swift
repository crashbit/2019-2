//
//  ViewController.swift
//  Dia16022019-1
//
//  Created by Germán Santos Jaimes on 2/16/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var etiqueta: UILabel!
    var datos : String = ""
    
    @IBOutlet weak var caja: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(datos)
        print("viewDidLoad")
        etiqueta.isHidden = true
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        print(datos)
        print("viewWillAppear")
        etiqueta.isHidden = false
        etiqueta.text = datos
    }

    @IBAction func valorar(_ sender: UIButton) {
        
        if let valor = Int(caja.text!){
            if valor % 2 == 0{
                print("Es par")
            }else{
                print("Es impar")
            }
        }else{
            print("no hay valor")
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toSecondView"{
            let secondView = segue.destination as? SecondViewController
            secondView?.valor = caja.text!
        }
        
        if segue.identifier == "toThirdView"{
            let thirdView = segue.destination as? ThirdViewController
            thirdView?.firstViewController = self
        }
    }
    
    @IBAction func unsegue( segue: UIStoryboardSegue){
       
    }
    
    func dataReceived( data: String){
        print(data)
        datos = data
    }
    
    
}

