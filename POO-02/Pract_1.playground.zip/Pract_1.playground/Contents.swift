import UIKit

/*
 El uso de var es para crear tipos de datos cuyo valor cambiará durante el tiempo de ejecución del programa
*/

var nombre: String = "José"
/*
 El uso de let es para crear tipos de datos cuyo valor permanecerá constante durante el tiempo de ejecución del programa
*/

 let calculo = 3.1519

/*
 Tipos de datos basico:
 String
 Int
 Double
 Bool
 */

// Tipado por inferiencia
var edad = 20

// Tipado estricto
var color: String = "Rojo"







