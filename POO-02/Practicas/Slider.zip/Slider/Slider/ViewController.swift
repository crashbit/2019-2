//
//  ViewController.swift
//  Slider
//
//  Created by Germán Santos Jaimes on 2/19/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var slider: UISlider!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    
    @IBAction func seMovio(_ sender: UISlider) {
        let color = CGFloat(slider.value)
        
        view.backgroundColor = UIColor(white: color, alpha: 1.0)
        
        switch color {
        case 0.0 ..< 0.333:
            imageView.image = UIImage(named: "imagen1")
        case 0.333 ..< 0.666:
            imageView.image = UIImage(named: "imagen2")
        case 0.666 ... 1.0:
            imageView.image = UIImage(named: "imagen3")
        default:
            print("no pasa nada")
        }
        
    }
    
}

