//
//  ViewController.swift
//  MPOO03-12032019
//
//  Created by Germán Santos Jaimes on 3/12/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    let bt: UIButton = {
        let b = UIButton(type: .system)
        b.setTitle("click please", for: .normal)
        b.addTarget(self, action: #selector(click), for: .touchUpInside)
        b.translatesAutoresizingMaskIntoConstraints = false
        
        return b
    }()
    
    let botoncito: Botoncito = {
        let b = Botoncito()
        b.setTitle("click please pleas please", for: .normal)
        b.translatesAutoresizingMaskIntoConstraints = false
        return b
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(bt)
        view.addSubview(botoncito)
        bt.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        bt.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        
        botoncito.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        botoncito.centerYAnchor.constraint(equalTo: bt.topAnchor, constant: -20).isActive = true
        
    }
    
    
    @objc func click(){
        print("test")
    }

}

