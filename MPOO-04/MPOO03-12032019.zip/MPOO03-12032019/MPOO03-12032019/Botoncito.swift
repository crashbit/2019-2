//
//  Botoncito.swift
//  MPOO03-12032019
//
//  Created by Germán Santos Jaimes on 3/12/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class Botoncito: UIButton{
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .red
        self.layer.cornerRadius = 50
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
