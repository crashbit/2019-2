//
//  ViewController.swift
//  Persistencia
//
//  Created by Germán Santos Jaimes on 5/14/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var caja: UITextField!
    
    var defaults = UserDefaults.standard
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func viewDidAppear(_ animated: Bool) {
        if let datos = defaults.object(forKey: "datos") as? String, datos != ""{
            caja.text = datos
            
            performSegue(withIdentifier: "SecondView", sender: self)
            
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if let datos = defaults.object(forKey: "datos") as? String{
            caja.text = datos
            performSegue(withIdentifier: "SecondView", sender: self)
        }
        else{
            print("No hubo datos")
        }
    }

    @IBAction func guardar(_ sender: UIButton) {
        
        if let datos = caja.text, datos != ""{
            defaults.set(datos, forKey: "datos")
            print("Datos guardados")
        }
        
        
    }
}

