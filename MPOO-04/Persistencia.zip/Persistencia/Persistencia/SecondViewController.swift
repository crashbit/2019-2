//
//  SecondViewController.swift
//  Persistencia
//
//  Created by Germán Santos Jaimes on 5/14/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    var defaults = UserDefaults.standard
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func borrarDatos(_ sender: UIButton){
        
        defaults.set("", forKey: "datos")
        dismiss(animated: true, completion: nil)
        
    }

}
