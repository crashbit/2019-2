//
//  SecondViewController.swift
//  Tablas_MPOO04
//
//  Created by Germán Santos Jaimes on 2/26/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var nombre: UILabel!
    var dato: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        nombre.text = dato
    }
    
    @IBAction func cerrar(_ sender: UIButton){
        dismiss(animated: true, completion: nil)
    }
}
