//
//  ItemCollectionViewCell.swift
//  MPOO04-CollectionView
//
//  Created by Germán Santos Jaimes on 3/26/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class ItemCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
    override func awakeFromNib() {
        layer.cornerRadius = 10
    }
    
}
