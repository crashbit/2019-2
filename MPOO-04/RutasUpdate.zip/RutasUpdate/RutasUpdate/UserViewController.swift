//
//  UserViewController.swift
//  RutasUpdate
//
//  Created by Germán Santos Jaimes on 5/14/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit
import MapKit
import Firebase

class UserViewController: UIViewController {

    @IBOutlet weak var mapa: MKMapView!
    
    var ref: DocumentReference!
    var getRef: Firestore!
    
    var longitud: CLLocationDegrees!
    var latitud: CLLocationDegrees!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        getCoords()
    }
    
    func getCoords(){
        
        
        
        getRef.collection("coordenadas").addSnapshotListener { (querySnapshot, error) in
            if let error = error{
                print(error.localizedDescription)
            }else{
                for document in querySnapshot!.documents {
                    let id = document.documentID
                    let values = document.data()
                    self.latitud = values["latitud"] as? CLLocationDegrees
                    self.longitud = values["longitud"] as? CLLocationDegrees
                    print(self.longitud, self.latitud)
                    let localizacion = CLLocationCoordinate2D(latitude: self.latitud, longitude: self.longitud)
                    let span = MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
                    let region = MKCoordinateRegion(center: localizacion, span: span)
                    self.mapa.setRegion(region, animated: true)
                    self.mapa.showsUserLocation = true
                }
            }
            
            
        }
        
    }
    

}
