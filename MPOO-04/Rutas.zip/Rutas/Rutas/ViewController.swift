//
//  ViewController.swift
//  Rutas
//
//  Created by Germán Santos Jaimes on 5/7/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController, MKMapViewDelegate {

    @IBOutlet weak var mapa: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let inicioLocation = CLLocationCoordinate2D(latitude: 24.019894, longitude: -104.660824)
        let destinoLocation = CLLocationCoordinate2D(latitude: 24.023059, longitude: -104.652279)
        
        let inicioPin = Direccion(title: "Direccion1", subtitle: "inicio", coordinate: inicioLocation)
        
        let destinoPin = Direccion(title: "Direccion", subtitle: "destino", coordinate: destinoLocation)
        
        self.mapa.addAnnotation(inicioPin)
        self.mapa.addAnnotation(destinoPin)
        
        let inicioPlaceMark = MKPlacemark(coordinate: inicioLocation)
        let destinoPlaceMark = MKPlacemark(coordinate: destinoLocation)
        
        let directionRequest = MKDirections.Request()
        directionRequest.source = MKMapItem(placemark: inicioPlaceMark)
        directionRequest.destination = MKMapItem(placemark: destinoPlaceMark)
        directionRequest.transportType = .automobile
        
        let directions = MKDirections(request: directionRequest)
        directions.calculate { (response, error) in
            
            guard let directionResponse = response else {
                if let error = error{
                    print(error.localizedDescription)
                }
                return
            }
            
            let ruta = directionResponse.routes[0]
            self.mapa.addOverlay(ruta.polyline, level: .aboveRoads)
            let rect = ruta.polyline.boundingMapRect
            self.mapa.setRegion(MKCoordinateRegion(rect), animated: true)
        }
        
        self.mapa.delegate = self
        
        let inicio = CLLocation(latitude: 24.019894, longitude: -104.660824)
        let destino = CLLocation(latitude: 24.023059, longitude: -104.652279)
        
        let distancia : CLLocationDistance = inicio.distance(from: destino)
        print(distancia)
        
        let distanciaReal = String(format: "Distancia %02.02f metros", distancia)
        print(distanciaReal)

    }
    
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        let linea = MKPolylineRenderer(overlay: overlay)
        linea.strokeColor = UIColor.red
        linea.lineWidth = 4.0
        return linea
    }


}

