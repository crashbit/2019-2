//
//  ViewController.swift
//  ImageStorageFirebase
//
//  Created by Germán Santos Jaimes on 4/15/19.
//  Copyright © 2019 Germán Santos Jaimes. All rights reserved.
//

import UIKit
import MobileCoreServices
import Firebase
import FirebaseUI


class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var userProfileImageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let storageReference = Storage.storage().reference()
        let userImageDownloadUrlReference = storageReference.child("/photos/picture")
        
        //Colocamos un placeholder
        let placeHolderImage = UIImage(named: "fa-image")
        
        userProfileImageView.sd_setImage(with: userImageDownloadUrlReference, placeholderImage: placeHolderImage)
        
        userImageDownloadUrlReference.downloadURL { (url, error) in
            if let error = error{
                print(error.localizedDescription)
            }else{
                print("url de descarga: \(String(describing: url!))")
            }
        }
        
    }

    @IBAction func setImage(_ sender: UIButton) {
        let userImagePicker = UIImagePickerController()
        userImagePicker.sourceType = UIImagePickerController.SourceType.photoLibrary
        userImagePicker.mediaTypes = [kUTTypeImage as String]
        userImagePicker.delegate = self
        present(userImagePicker, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        if let userImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage, let optimizedImageData = userImage.jpegData(compressionQuality: 0.6){
            
            uploadUserImage(imageData: optimizedImageData)
            
        }
        picker.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
    func uploadUserImage(imageData: Data){
        let activityIndicator = UIActivityIndicatorView.init(style: .gray)
        activityIndicator.startAnimating()
        activityIndicator.center = self.view.center
        self.view.addSubview(activityIndicator)
        
        
        let storageReference = Storage.storage().reference()
        let userImageRef = storageReference.child("/photos").child("picture")
        
        let uploadMetada = StorageMetadata()
        uploadMetada.contentType = "image/jpeg"
        
        userImageRef.putData(imageData, metadata: uploadMetada) { (storageMetaData, error) in
            activityIndicator.stopAnimating()
            activityIndicator.removeFromSuperview()
            
            if let error = error{
                print(error.localizedDescription)
            }else{
                print("Metadata de los datos: " , storageMetaData)
            }
        }
    }
    
}

