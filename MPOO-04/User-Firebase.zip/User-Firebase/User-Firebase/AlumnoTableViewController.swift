//
//  AlumnoTableViewController.swift
//  User-Firebase
//
//  Created by Germán Santos Jaimes on 4/23/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit
import Firebase

class AlumnoTableViewController: UITableViewController{
    
    var alumnos: [Alumno] = []
    
    var ref: DocumentReference!
    var getRef: Firestore!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getRef = Firestore.firestore()
    
    }
    
    
    func getAlumnos(){
        getRef.collection("alumno").getDocuments { (querySnapshot, error) in
            if let error = error{
                print(error.localizedDescription)
            }else{
                for document in querySnapshot!.documents{
                    let id = document.documentID
                    let values = document.data()
                    let nombre = values["nombre"] as? String ?? "sin nombre"
                    let apellido = values["apellido"] as? String ?? "sin apellido"
                    let alumno = Alumno(id: id, nombre: nombre, apellido: apellido)
                    self.alumnos.append(alumno)
                }
            }
        }
    }
    
}
