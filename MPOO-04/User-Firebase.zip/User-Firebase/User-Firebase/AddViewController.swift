//
//  AddViewController.swift
//  User-Firebase
//
//  Created by Germán Santos Jaimes on 4/8/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit
import Firebase


class AddViewController: UIViewController {

    @IBOutlet weak var nombreTF: UITextField!
    @IBOutlet weak var apellidoTF: UITextField!
    
    var ref: DocumentReference!
    var getRef: Firestore!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getRef = Firestore.firestore()
    }
    
    @IBAction func addAlumno(_ sender: UIButton){
        var datos: [String: Any] = ["nombre": nombreTF.text, "apellido":apellidoTF.text]
        
        ref = getRef.collection("alumno").addDocument(data: datos, completion: { (error) in
            if let error = error {
                print(error.localizedDescription)
            }else{
                print("Se guardaron exitosamente los datos")
                self.navigationController?.popViewController(animated: true)
            }
        })
    }
    
}
