//
//  LoginViewController.swift
//  User-Firebase
//
//  Created by Germán Santos Jaimes on 4/3/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit
import Firebase

class LoginViewController: UIViewController {

    @IBOutlet weak var email: UITextField!
    
    
    @IBOutlet weak var password: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    

    @IBAction func login(_ sender: UIButton) {
        guard let userEmail = email.text,userEmail != "", let userPass = password.text, userPass != "" else {
            return
        }
        
        Auth.auth().signIn(withEmail: userEmail, password: userPass) { (user, error) in
            if let error = error{
                print(error.localizedDescription)
                return
            }
            
            self.dismiss(animated: true, completion: nil)
        
        }
        
       
        
    }
    
}
