//
//  SearchViewController.swift
//  Mapas
//
//  Created by Germán Santos Jaimes on 5/2/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit
import MapKit

class SearchViewController: UIViewController, UISearchBarDelegate {

    @IBOutlet weak var buscar: UISearchBar!
    @IBOutlet weak var mapa: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        buscar.delegate = self
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        buscar.resignFirstResponder()
        
        let geocoder = CLGeocoder()
        
        geocoder.geocodeAddressString(buscar.text!) { (places:[CLPlacemark]?, error:Error?) in
            
            if let error = error{
                print(error.localizedDescription)
            }else{
                
                let place = places?.first
                let anotacion = MKPointAnnotation()
                anotacion.coordinate = (place?.location?.coordinate)!
                anotacion.title = self.buscar.text
                
                let span = MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
                
                let region = MKCoordinateRegion(center: anotacion.coordinate, span: span)
                
                self.mapa.setRegion(region, animated: true)
                self.mapa.addAnnotation(anotacion)
                self.mapa.selectAnnotation(anotacion, animated: true)
            }
        }
    }
}
