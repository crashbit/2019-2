//
//  AddViewController.swift
//  User-Firebase
//
//  Created by Germán Santos Jaimes on 4/8/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit
import Firebase



class AddViewController: UIViewController {

    @IBOutlet weak var cajita: UITextField!
    var ref: DatabaseReference!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func agregar(_ sender: UIButton){
        let postDatabaseRef = Database.database().reference().child("test")
        ref.childByAutoId().key
        
        
        guard let dato = cajita.text, dato != "" else  {
            print("hola")
            return
        }
        
        let post: [String: String] = ["nombre": dato ]
        postDatabaseRef.setValue(post) { (error, databaseref) in
            if let error = error{
                print(error.localizedDescription)
            }
            print("Esta es la llave que da firebase" + databaseref.key)
        }
    }

    
}
