//
//  SecondViewController.swift
//  proy2_mpoo03
//
//  Created by Germán Santos Jaimes on 2/11/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    
    @IBOutlet weak var saludo: UILabel!
    
    var deVistaUno: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .red
        saludo.text = deVistaUno
        
    }

}
