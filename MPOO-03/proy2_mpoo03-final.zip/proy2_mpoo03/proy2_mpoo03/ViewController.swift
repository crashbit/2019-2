//
//  ViewController.swift
//  proy2_mpoo03
//
//  Created by Germán Santos Jaimes on 2/11/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var caja: UITextField!
    
    @IBOutlet weak var resultado: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func ejecutar(_ sender: UIButton) {
        if let numero = Int(caja.text!){
            if numero % 2 == 0{
                resultado.text = "Es par"
            }else{
                resultado.text = "Es impar"
            }
        }
    
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "ViewTwo"{
            
            let vistaDestino = segue.destination as? SecondViewController
            vistaDestino?.deVistaUno = "Saludos de vista 1"
            
        }
    }
    
    
    
    
    
    @IBAction func unsegue(_ segue: UIStoryboardSegue){
        
    }
    
   
    
}

