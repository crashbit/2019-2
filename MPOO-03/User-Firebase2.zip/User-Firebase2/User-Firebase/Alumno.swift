//
//  Alumno.swift
//  User-Firebase
//
//  Created by Germán Santos Jaimes on 4/24/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class Alumno{
    var id: String?
    var nombre: String?
    var apellido: String?
    
    init(id: String, nombre: String, apellido:String){
        self.id = id
        self.nombre = nombre
        self.apellido = apellido
    }
}
