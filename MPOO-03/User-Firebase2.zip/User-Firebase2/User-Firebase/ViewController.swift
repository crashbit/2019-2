//
//  ViewController.swift
//  User-Firebase
//
//  Created by Germán Santos Jaimes on 4/3/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit
import Firebase

class ViewController: UIViewController {

    @IBOutlet weak var email: UITextField!
    
    @IBOutlet weak var password: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    

    @IBAction func createUser(_ sender: UIButton) {
        
        guard let userEmail = email.text,userEmail != "", let userPass = password.text, userPass != "" else {
            return
        }
        
        Auth.auth().createUser(withEmail: userEmail, password: userPass) { (user, error) in
            
            if let error = error{
                print(error.localizedDescription)
                return
            }
            print("Se creo el usuario: " )
        }
    }
    
    
    
}

