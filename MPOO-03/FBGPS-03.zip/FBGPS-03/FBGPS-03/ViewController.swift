//
//  ViewController.swift
//  FBGPS-03
//
//  Created by Germán Santos Jaimes on 5/8/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
import Firebase

class ViewController: UIViewController, CLLocationManagerDelegate {

    @IBOutlet weak var mapa: MKMapView!
    
    var manager = CLLocationManager()
    
    var latitud: CLLocationDegrees!
    var longitud: CLLocationDegrees!
    
    var ref: DocumentReference!
    var getRef: Firestore!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        manager.delegate = self
        manager.requestWhenInUseAuthorization()
        manager.desiredAccuracy = kCLLocationAccuracyBest
        manager.startUpdatingLocation()
        
        getRef = Firestore.firestore()
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.first{
            self.longitud = location.coordinate.longitude
            self.latitud = location.coordinate.latitude
        }
        
        var datos: [String: Any] = ["latitud": latitud, "longitud": longitud]
        
        ref = getRef.collection("coordenada").addDocument(data: datos
            , completion: { (error) in
                if let error = error{
                    print(error.localizedDescription)
                }else{
                    print("Datos guardados")
                }
        })
        
    }

    @IBAction func inicia(_ sender: UIButton) {
        let localizacion = CLLocationCoordinate2D(latitude: latitud, longitude: longitud)
        
        let span = MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
        let region = MKCoordinateRegion(center: localizacion, span: span)
        
        mapa.setRegion(region, animated: true)
        mapa.showsUserLocation = true
    }
    
}

