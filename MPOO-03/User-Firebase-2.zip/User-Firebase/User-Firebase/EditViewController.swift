//
//  EditViewController.swift
//  User-Firebase
//
//  Created by Germán Santos Jaimes on 4/25/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit
import Firebase
import FirebaseUI
import MobileCoreServices

class EditViewController: UIViewController{
    
    @IBOutlet weak var nombreTF: UITextField!
    @IBOutlet weak var apellidoTF: UITextField!
    
    @IBOutlet weak var photo: UIImageView!
    
    
    var ref: DocumentReference!
    var getRef: Firestore!
    
    var alumno: Alumno!
    var id:String = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        nombreTF.text = alumno.nombre
        apellidoTF.text = alumno.apellido
        id = alumno.id!
        
        ref = Firestore.firestore().collection("alumno").document(id)
        let storageReference = Storage.storage().reference()
        let photoDownload = storageReference.child("/photos/" + id)
        
        let placeHolder = UIImage(named: "fa-image-1")
        
        
        photo.sd_setImage(with: storageReference, placeholderImage: placeHolder)
        
        photoDownload.downloadURL { (url, error) in
            if let error = error{
                print(error.localizedDescription)
            }else{
                print("url: \(String(describing: url!))")
                
            }
        }
        
    }
    
    @IBAction func editAlumno(_ sender: UIButton){
        let values: [String: Any] = ["nombre": nombreTF.text, "apellido": apellidoTF.text]
        
        ref.setData(values) { (error) in
            if let error = error{
                print(error.localizedDescription)
            }else{
                print("datos actualizados")
            }
        }
        
        dismiss(animated: true, completion: nil)
        
    }
    
    
}
