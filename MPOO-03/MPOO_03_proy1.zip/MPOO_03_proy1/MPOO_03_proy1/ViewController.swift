//
//  ViewController.swift
//  MPOO_03_proy1
//
//  Created by Germán Santos Jaimes on 2/6/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var suficiente: UILabel!
    @IBOutlet weak var etiqueta: UILabel!
    var contador: Int = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        etiqueta.text = "Bienvenido a Inge"
    }

    @IBAction func sumar(_ sender: UIButton) {
        
        if contador < 26{
            contador += 1
            etiqueta.text = String(contador)
        }else{
            suficiente.isHidden = false
        }
    }
}

