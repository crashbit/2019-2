//
//  SearchMapViewController.swift
//  MapasMPOO03
//
//  Created by Germán Santos Jaimes on 5/6/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit
import MapKit

class SearchMapViewController: UIViewController, UISearchBarDelegate {

    
    @IBOutlet weak var mapa: MKMapView!
    @IBOutlet weak var buscador: UISearchBar!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        buscador.delegate = self
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        buscador.resignFirstResponder()
        
        let geocoder = CLGeocoder()
        geocoder.geocodeAddressString(searchBar.text!) { (places: [CLPlacemark]?, error: Error?) in
            
            if let error = error{
                print(error.localizedDescription)
            }else{
                let place = places?.first
                let anotacion = MKPointAnnotation()
                
                anotacion.coordinate = (place?.location!.coordinate)!
                print(place?.country, place?.administrativeArea)
                anotacion.title = searchBar.text
                
                let span = MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
                let region = MKCoordinateRegion(center: anotacion.coordinate, span: span)
                
                self.mapa.setRegion(region, animated: true)
                self.mapa.addAnnotation(anotacion)
                self.mapa.selectAnnotation(anotacion, animated: true)
                
            }
        }
    }
}
