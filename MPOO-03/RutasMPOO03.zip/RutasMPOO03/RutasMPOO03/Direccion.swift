//
//  Direccion.swift
//  RutasMPOO03
//
//  Created by Germán Santos Jaimes on 5/8/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit
import MapKit

class Direccion: NSObject, MKAnnotation{
    var coordinate: CLLocationCoordinate2D
    var title: String?
    var subtitle: String?
    
    init(title: String, subtitle: String, location: CLLocationCoordinate2D){
        self.title = title
        self.subtitle = subtitle
        self.coordinate = location
    }
    
}
