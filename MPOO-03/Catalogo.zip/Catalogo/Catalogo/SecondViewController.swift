//
//  SecondViewController.swift
//  Catalogo
//
//  Created by Germán Santos Jaimes on 2/25/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var caja: UITextField!
    @IBOutlet weak var nombre: UILabel!
    @IBOutlet weak var apellidos:  UILabel!
    var dato: Alumno!
    
    var firstView : ViewController!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        nombre.text = dato.nombre
        apellidos.text = dato.apellidos
    }
    

    @IBAction func actualizar(_ sender: UIButton) {
        if let valor = caja.text{
            let indexPath = firstView.tablita.indexPathForSelectedRow
            firstView.alumnos[(indexPath?.row)!].promedio = Double(valor)!
        }
        dismiss(animated: true, completion: nil)
    }
    

}
