//
//  Alumno.swift
//  Catalogo
//
//  Created by Germán Santos Jaimes on 2/25/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import Foundation

struct Alumno{
    var nombre: String
    var apellidos: String
    var promedio: Double = 0.0
    var foto: String
}
