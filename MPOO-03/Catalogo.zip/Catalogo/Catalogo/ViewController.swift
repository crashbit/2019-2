//
//  ViewController.swift
//  Catalogo
//
//  Created by Germán Santos Jaimes on 2/25/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var tablita: UITableView!
    @IBOutlet weak var etiqueta: UILabel!
    
    var alumnos: [Alumno] = [
        Alumno(nombre:"Pedro", apellidos: "Perez"),
        Alumno(nombre: "Juan", apellidos: "juanes"),
        Alumno(nombre: "Lola", apellidos: "Salinas")
    ]

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return alumnos.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath)
        
        cell.textLabel?.text = alumnos[indexPath.row].nombre
        
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        etiqueta.text = alumnos[indexPath.row].nombre
        let cell = tablita.cellForRow(at: indexPath)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let indexPath = tablita.indexPathForSelectedRow
        let secondView = segue.destination as? SecondViewController
        secondView?.dato = alumnos[(indexPath?.row)!]
    }
    
   


}

