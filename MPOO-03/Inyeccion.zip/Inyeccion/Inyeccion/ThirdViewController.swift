//
//  ThirdViewController.swift
//  Inyeccion
//
//  Created by Germán Santos Jaimes on 2/20/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {

    var viewController : ViewController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .green
        // Do any additional setup after loading the view.
    }
    

    @IBAction func regresar(){
        
        viewController.dato = "Hola mundo"
        dismiss(animated: true, completion: nil)
    }

}
