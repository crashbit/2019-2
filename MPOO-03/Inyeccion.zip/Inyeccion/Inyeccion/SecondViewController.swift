//
//  SecondViewController.swift
//  Inyeccion
//
//  Created by Germán Santos Jaimes on 2/20/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var etiqueta : UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func regresar( sender: UIButton){
        navigationController?.popViewController(animated: true)
    }

}
