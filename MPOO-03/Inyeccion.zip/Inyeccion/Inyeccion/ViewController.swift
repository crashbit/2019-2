//
//  ViewController.swift
//  Inyeccion
//
//  Created by Germán Santos Jaimes on 2/20/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var etiqueta: UILabel!
    var dato : String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        etiqueta.isHidden = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        etiqueta.text = dato
        etiqueta.isHidden = false
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toThird"{
            let thirdView = segue.destination as? ThirdViewController
            thirdView?.viewController = self
        }
    }

}

