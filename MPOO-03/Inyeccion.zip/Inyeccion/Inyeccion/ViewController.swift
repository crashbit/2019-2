//
//  ViewController.swift
//  Inyeccion
//
//  Created by Germán Santos Jaimes on 2/20/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

